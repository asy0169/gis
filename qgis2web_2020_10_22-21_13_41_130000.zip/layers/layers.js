var wms_layers = [];
var baseLayer = new ol.layer.Group({
    'title': '',
    layers: [
new ol.layer.Tile({
    'title': 'OSM HOT',
    'type': 'base',
    source: new ol.source.XYZ({
        url: 'http://{a-c}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png',
        attributions: [new ol.Attribution({html: '&copy; <a href="http://openstreetmap.org">OpenStreetMap</a> contributors,<a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>,Tiles courtesy of <a href="http://hot.openstreetmap.org/" target="_blank">Humanitarian OpenStreetMap Team</a>'})]
    })
})
]
});
var format_Volcano_0 = new ol.format.GeoJSON();
var features_Volcano_0 = format_Volcano_0.readFeatures(json_Volcano_0, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_Volcano_0 = new ol.source.Vector({
    attributions: [new ol.Attribution({html: '<a href=""></a>'})],
});
jsonSource_Volcano_0.addFeatures(features_Volcano_0);var lyr_Volcano_0 = new ol.layer.Vector({
                declutter: true,
                source:jsonSource_Volcano_0, 
                style: style_Volcano_0,
    title: 'Volcano<br />\
    <img src="styles/legend/Volcano_0_0.png" /> 1500~1699<br />\
    <img src="styles/legend/Volcano_0_1.png" /> 1700~1799<br />\
    <img src="styles/legend/Volcano_0_2.png" /> 1800~1899<br />\
    <img src="styles/legend/Volcano_0_3.png" /> 1900~1963<br />\
    <img src="styles/legend/Volcano_0_4.png" /> 1964~<br />\
    <img src="styles/legend/Volcano_0_5.png" /> AD 1~1499<br />\
    <img src="styles/legend/Volcano_0_6.png" /> Holocene<br />\
    <img src="styles/legend/Volcano_0_7.png" /> Holocene_Uncertain<br />\
    <img src="styles/legend/Volcano_0_8.png" /> Probable_Holocene<br />\
    <img src="styles/legend/Volcano_0_9.png" /> Unknown<br />\
    <img src="styles/legend/Volcano_0_10.png" /> <br />'
        });

lyr_Volcano_0.setVisible(true);
var layersList = [baseLayer,lyr_Volcano_0];
lyr_Volcano_0.set('fieldAliases', {'Number': 'Number', 'Volcano_Na': 'Volcano_Na', 'Country': 'Country', 'Latitude': 'Latitude', 'Longitude': 'Longitude', 'Last_Known': 'Last_Known', });
lyr_Volcano_0.set('fieldImages', {'Number': 'TextEdit', 'Volcano_Na': 'TextEdit', 'Country': 'TextEdit', 'Latitude': 'TextEdit', 'Longitude': 'TextEdit', 'Last_Known': 'TextEdit', });
lyr_Volcano_0.set('fieldLabels', {'Number': 'header label', 'Volcano_Na': 'header label', 'Country': 'header label', 'Latitude': 'header label', 'Longitude': 'header label', 'Last_Known': 'header label', });
lyr_Volcano_0.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});